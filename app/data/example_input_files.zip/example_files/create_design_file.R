# This script automatizes the creation of the design file as TSV to make your life
# easier. It is not mandatory to use it and the TSV file proposed may not suit you.
#
# To use this script, your MassHunter file must have a `File Name` column.
# The content of this column must follow the following pattern:
## <condition>_<replicate>.D
## Examples:
## BlancFibre_1.D   BlancFibre_2.D
## YC0405000_1.D    YC0405000_2.D
## Scerevisiae0208_A.D  Scerevisiae0208_B.D
## Brett045_first_replicate.D  Brett045_second_replicate.D
## syntheticMust1_A  syntheticMust1_B
##
## The separator is an underscore (_) and ONLY the FIRST one will be counted.
## The other underscores will be ignored.
## The .D is optional
# You may as well change the code according to your needs.

################################################################################
# CHANGE THE TWO VARIABLES BELOW
MASSHUNTER.FILE <- "FSbread_masshunter_file.csv" # CHANGE HERE AND PUT YOUR MASSHUNTER FILE NAME
DESIGN.FILE.NAME <- "FSbread_design_file.tsv" # CHANGE HERE AND PUT YOUR DESIGN FILE NAME

################################################################################
################################################################################
################################################################################

main <- function(file, outname) {
	df <- read.csv(file)

	file.name <- sort(unique(df$File.Name))
	split.file <- strsplit(file.name, split="_")
	condition <- unlist(lapply(split.file, function(x) x[1]))
	replicate <- unlist(lapply(split.file, function(x) {
		element <- x[2:length(x)]
		element <- paste(element, collapse="_")
		element <- gsub(pattern="\\.D", replacement="", x=element)
		return(element)
	}))
	design.file <- data.frame(File.Name = file.name,
				  Condition = condition,
				  Replicate = replicate,
				  Label = condition
	)
	write.table(design.file, file=outname, quote=FALSE, sep='\t', row.names=FALSE)
}

if (MASSHUNTER.FILE %in% list.files()) {
    main(MASSHUNTER.FILE, DESIGN.FILE.NAME)
    cat(paste(DESIGN.FILE.NAME, " succesfully created", sep=""))
} else {
    cat(paste("Make sure to be in the right working directory. The current one is ", getwd(), sep=""))
}